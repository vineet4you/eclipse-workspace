package com.example.demo.Covid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
